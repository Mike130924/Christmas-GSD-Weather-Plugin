# Christmas GSD Weather Plugin

A new, independent Android wallpaper-provider plugin for Projectivy Launcher.

This repository contains its own Android application, settings entry point, renderer implementation (in progress), and the official Projectivy wallpaper-provider IPC contract needed for compatibility. No third-party renderer implementation is used.

See `docs/PROJECT_STATUS.md` for verified work and outstanding validation.


## Settings improvements (0.2.0)

- The theme-name input explicitly participates in Android TV remote focus navigation.
- Changing the weather readout size requests a preview-only render. The preview is written to
  `wallpaper/preview.png`; it does not overwrite the live wallpaper or save the slider value.
- The settings screen can check the repository's latest GitHub Release, download its APK,
  show download progress, and hand the APK to Android's package installer. Android still
  requires user confirmation.

### Important: APK update signing

Android only accepts an in-place update when the downloaded APK is signed with the same
certificate as the installed app. The current CI workflow builds a debug APK and GitHub-hosted
runners do not retain their generated debug keystore between runs. Therefore, APKs built by
separate CI runs are not guaranteed to be installable as updates over one another.

Before publishing APK assets for in-app updates, configure a persistent release keystore and
sign every release with it. If the currently installed APK was signed by a previous ephemeral
GitHub Actions debug keystore, it will need a one-time uninstall/reinstall using the persistent
release-signed APK (back up plugin settings first). Plugin settings and saved themes are stored
in app-private data and are preserved by a normal same-signature update.
